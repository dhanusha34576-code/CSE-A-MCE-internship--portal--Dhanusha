<?php

session_start();

/* Company role */
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "company";
}
$companyName = "Tech Solutions";
$internships = [

    1 => [
        "title" => "PHP Web Development Intern",
        "location" => "Chennai / Remote",
        "duration" => "3 Months",
        "skills" => "PHP, MySQL, HTML, CSS",
        "applicants" => 8,
        "status" => "Active"
    ],

    2 => [
        "title" => "Python Developer Intern",
        "location" => "Bangalore / Remote",
        "duration" => "3 Months",
        "skills" => "Python, SQL, Git",
        "applicants" => 5,
        "status" => "Active"
    ],

    3 => [
        "title" => "Frontend Developer Intern",
        "location" => "Chennai",
        "duration" => "2 Months",
        "skills" => "HTML, CSS, JavaScript",
        "applicants" => 4,
        "status" => "Active"
    ],

    4 => [
        "title" => "Java Developer Intern",
        "location" => "Chennai / Remote",
        "duration" => "3 Months",
        "skills" => "Java, OOP, MySQL",
        "applicants" => 6,
        "status" => "Active"
    ],

    5 => [
        "title" => "Data Analyst Intern",
        "location" => "Coimbatore",
        "duration" => "3 Months",
        "skills" => "Python, Excel, SQL",
        "applicants" => 7,
        "status" => "Active"
    ],

    6 => [
        "title" => "UI/UX Design Intern",
        "location" => "Chennai",
        "duration" => "2 Months",
        "skills" => "Figma, UI/UX, Photoshop",
        "applicants" => 3,
        "status" => "Active"
    ],

    7 => [
        "title" => "Cloud Computing Intern",
        "location" => "Bangalore / Remote",
        "duration" => "4 Months",
        "skills" => "AWS, Cloud, Linux",
        "applicants" => 9,
        "status" => "Active"
    ],

    8 => [
        "title" => "Cyber Security Intern",
        "location" => "Chennai / Remote",
        "duration" => "3 Months",
        "skills" => "Networking, Linux, Security",
        "applicants" => 5,
        "status" => "Active"
    ],

    9 => [
        "title" => "Mobile App Development Intern",
        "location" => "Coimbatore",
        "duration" => "3 Months",
        "skills" => "Flutter, Dart, Firebase",
        "applicants" => 4,
        "status" => "Active"
    ],

    10 => [
        "title" => "Machine Learning Intern",
        "location" => "Bangalore / Remote",
        "duration" => "4 Months",
        "skills" => "Python, ML, Pandas",
        "applicants" => 10,
        "status" => "Active"
    ]
];
$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}
$filteredInternships = [];

foreach ($internships as $id => $internship) {

    if ($search == "") {

        $filteredInternships[$id] = $internship;

    } else {

        if (
            stripos($internship["title"], $search) !== false ||
            stripos($internship["location"], $search) !== false ||
            stripos($internship["skills"], $search) !== false
        ) {
            $filteredInternships[$id] = $internship;
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<title>My Internships - Company</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f2f6fa;
}

.header {
    background: #172B4D;
    color: white;
    padding: 22px;
    text-align: center;
}

.header h1 {
    margin: 0;
}

.header p {
    margin: 8px 0 0;
}
.nav {
    background: white;
    padding: 15px;
    text-align: center;
    box-shadow: 0 2px 8px #ccc;
}

.nav a {
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
    margin: 0 12px;
}

.nav a:hover {
    text-decoration: underline;
}

.container {
    width: 90%;
    max-width: 1100px;
    margin: 30px auto;
}

.top-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.top-section h2 {
    color: #1f4e79;
}
.add-btn {
    background: #1f4e79;
    color: white;
    padding: 12px 18px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}

.add-btn:hover {
    background: #163b5c;
}

.search-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 25px;
    box-shadow: 0 3px 10px #ddd;
}

.search-box input {
    width: 80%;
    padding: 12px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

.search-box button {
    padding: 12px 20px;
    border: none;
    background: #1f4e79;
    color: white;
    border-radius: 6px;
    cursor: pointer;
}
.card-container {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.card {
    background: white;
    padding: 22px;
    border-radius: 10px;
    box-shadow: 0 3px 12px #ddd;
}

.card h3 {
    color: #1f4e79;
    margin-top: 0;
}

.card p {
    margin: 10px 0;
}

.label {
    font-weight: bold;
}
.status {
    display: inline-block;
    background: #d4edda;
    color: #155724;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: bold;
}
.buttons {
    margin-top: 18px;
}

.edit-btn,
.applicant-btn {
    display: inline-block;
    padding: 9px 14px;
    text-decoration: none;
    border-radius: 5px;
    margin-right: 5px;
}

.edit-btn {
    background: #ffc107;
    color: black;
}

.applicant-btn {
    background: #1f4e79;
    color: white;
}
.no-result {
    background: white;
    padding: 30px;
    text-align: center;
    border-radius: 10px;
    color: #777;
}

@media (max-width: 700px) {

    .card-container {
        grid-template-columns: 1fr;
    }

    .top-section {
        display: block;
    }

    .add-btn {
        display: inline-block;
        margin-top: 10px;
    }

    .search-box input {
        width: 70%;
    }

}

</style>

</head>

<body>

<div class="header">

    <h1>🏢 Company Internship Portal</h1>

    <p>Welcome, <?php echo htmlspecialchars($companyName); ?></p>

</div>

<div class="nav">

    <a href="dashboard.php">Dashboard</a>

    <a href="profile.php">Profile</a>

    <a href="add_internship.php">Add Internship</a>

    <a href="applicants.php">Applicants</a>

    <a href="../logout.php">Logout</a>

</div>
<div class="container">

    <div class="top-section">

        <div>
            <h2>📋 My Internships</h2>
            <p>Manage your internship opportunities.</p>
        </div>

        <a class="add-btn" href="add_internship.php">
            + Add Internship
        </a>

    </div>
    <div class="search-box">

        <form method="GET" action="">

            <input
                type="text"
                name="search"
                placeholder="Search internship..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <button type="submit">🔍 Search</button>

        </form>

</div>

    <?php if (count($filteredInternships) > 0) { ?>

        <div class="card-container">

            <?php foreach ($filteredInternships as $id => $internship) { ?>

                <div class="card">

                    <h3>
                        <?php echo htmlspecialchars($internship["title"]); ?>
                    </h3>

                    <p>
                        📍
                        <span class="label">Location:</span>
                        <?php echo htmlspecialchars($internship["location"]); ?>
                    </p>

                    <p>
                        ⏳
                        <span class="label">Duration:</span>
                        <?php echo htmlspecialchars($internship["duration"]); ?>
                    </p>

                    <p>
                        🛠️
                        <span class="label">Skills:</span>
                        <?php echo htmlspecialchars($internship["skills"]); ?>
                    </p>

                    <p>
                        👥
                        <span class="label">Applicants:</span>
                        <?php echo $internship["applicants"]; ?>
                    </p>

                    <p>
                        <span class="status">
                            <?php echo htmlspecialchars($internship["status"]); ?>
                        </span>
                    </p>

                    <div class="buttons">

                        <a
                            class="edit-btn"
                            href="edit_internship.php?id=<?php echo $id; ?>"
                        >
                            ✏️ Edit
                        </a>

                        <a
                            class="applicant-btn"
                            href="applicants.php?id=<?php echo $id; ?>"
                        >
                            👥 Applicants
                        </a>

                    </div>

                </div>

            <?php } ?>

        </div>

    <?php } else { ?>

        <div class="no-result">

            <h3>❌ No internships found</h3>

            <p>
                Try another search keyword.
            </p>

        </div>

    <?php } ?>

</div>

</body>

</html>