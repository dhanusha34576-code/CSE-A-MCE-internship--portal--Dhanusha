<?php

session_start();
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "company";
}
$companyName = "Tech Solutions";
$email = "company@techsolutions.com";
$phone = "";
$address = "";
$website = "";
$description = "";
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $companyName = trim($_POST["company_name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $address = trim($_POST["address"]);
    $website = trim($_POST["website"]);
    $description = trim($_POST["description"]);

    if (
        $companyName == "" ||
        $email == "" ||
        $phone == "" ||
        $address == "" ||
        $description == ""
    ) {

        $message = "Please fill all required fields.";

    } else {

        $message = "Company profile saved successfully.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Company Profile</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        header {
            background: #1f4e79;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .container {
            width: 80%;
            max-width: 700px;
            margin: 30px auto;
        }

        .form-box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ccc;
        }

        label {
            font-weight: bold;
        }

        input,
        textarea {
            width: 100%;
            padding: 12px;
            margin-top: 7px;
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        textarea {
            height: 120px;
            resize: vertical;
        }

        button {
            background: #1f4e79;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 5px;
            cursor: pointer;
        }

        .message {
            background: #e8f5e9;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .back {
            display: inline-block;
            margin-top: 20px;
            color: #1f4e79;
            text-decoration: none;
            font-weight: bold;
        }

    </style>

</head>

<body>

<header>

    <h1>🏢 Company Profile</h1>

    <p>Manage Company Information</p>

</header>

<div class="container">

    <div class="form-box">

        <?php

        if ($message != "") {
            echo '<div class="message">';
            echo htmlspecialchars($message);
            echo '</div>';
        }

        ?>

        <form method="POST" action="">

            <label>Company Name *</label>

            <input
                type="text"
                name="company_name"
                value="<?php echo htmlspecialchars($companyName); ?>"
                required
            >


            <label>Email *</label>

            <input
                type="email"
                name="email"
                value="<?php echo htmlspecialchars($email); ?>"
                required
            >


            <label>Phone Number *</label>

            <input
                type="tel"
                name="phone"
                value="<?php echo htmlspecialchars($phone); ?>"
                required
            >


            <label>Company Address *</label>

            <textarea
                name="address"
                required
            ><?php echo htmlspecialchars($address); ?></textarea>


            <label>Company Website</label>

            <input
                type="text"
                name="website"
                value="<?php echo htmlspecialchars($website); ?>"
                placeholder="https://example.com"
            >


            <label>Company Description *</label>

            <textarea
                name="description"
                required
            ><?php echo htmlspecialchars($description); ?></textarea>


            <button type="submit">
                Save Company Profile
            </button>

        </form>

    </div>

    <a class="back" href="dashboard.php">
        ← Back to Dashboard
    </a>

</div>

</body>

</html>