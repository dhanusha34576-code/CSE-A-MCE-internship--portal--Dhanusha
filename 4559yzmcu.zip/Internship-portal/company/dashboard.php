<?php

session_start();
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "company";
}
$companyName = "Tech Solutions";
$companyEmail = "company@techsolutions.com";
$totalInternships = 3;
$totalApplicants = 15;
$shortlistedApplicants = 5;
$pendingApplications = 7;
$welcomeMessage = "Welcome to Company Dashboard";

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Company Dashboard</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        header {
            background: #172B4D;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .container {
            width: 90%;
            margin: 30px auto;
        }

        .welcome {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
        }

        .cards {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .card {
            background: white;
            width: 200px;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 8px #ccc;
        }

        .card h2 {
            color: #1f4e79;
        }

        .menu {
            margin-top: 30px;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        .menu a {
            display: block;
            padding: 12px;
            margin: 8px 0;
            background: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .logout {
            background: #b22222 !important;
        }

    </style>

</head>

<body>

<header>

    <h1>🏢 Company Portal</h1>

    <p><?php echo htmlspecialchars($welcomeMessage); ?></p>

</header>

<div class="container">

    <div class="welcome">

        <h2>
            Hello, <?php echo htmlspecialchars($companyName); ?>!
        </h2>

        <p>
            Email:
            <?php echo htmlspecialchars($companyEmail); ?>
        </p>

        <p>
            Manage your internships and student applications from here.
        </p>

    </div>


    <!-- Dashboard Statistics -->

    <div class="cards">

        <div class="card">

            <h2>
                <?php echo $totalInternships; ?>
            </h2>

            <p>My Internships</p>

        </div>


        <div class="card">

            <h2>
                <?php echo $totalApplicants; ?>
            </h2>

            <p>Total Applicants</p>

        </div>


        <div class="card">

            <h2>
                <?php echo $shortlistedApplicants; ?>
            </h2>

            <p>Shortlisted</p>

        </div>


        <div class="card">

            <h2>
                <?php echo $pendingApplications; ?>
            </h2>

            <p>Pending Applications</p>

        </div>

    </div>


    <!-- Company Menu -->

    <div class="menu">

        <h2>Company Management</h2>

        <a href="profile.php">
            👤 My Company Profile
        </a>

        <a href="add_internship.php">
            ➕ Add Internship
        </a>

        <a href="internships.php">
            📋 My Internships
        </a>

        <a href="applicants.php">
            👥 View Applicants
        </a>

        <a href="../logout.php" class="logout">
            🚪 Logout
        </a>

    </div>

</div>

</body>

</html>