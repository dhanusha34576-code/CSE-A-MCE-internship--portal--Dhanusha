<?php

session_start();

if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "company";
}

$companyName = "Tech Solutions";
$message = "";
$search = "";
$applicants = [

    1 => [
        "name" => "Haseen R",
        "email" => "haseenrafi12@gmail.com",
        "college" => "ABC Engineering College",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "02-10-2026",
        "status" => "Under Review"
    ],

    2 => [
        "name" => "Dhanusha K",
        "email" => "dhanusha34576@gmail.com",
        "college" => "XYZ Engineering College",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "01-10-2026",
        "status" => "Shortlisted"
    ],

    3 => [
        "name" => "Geethavarshini R",
        "email" => "@gmail.com",
        "college" => "Mahendra Engineering College",
        "internship" => "Python Developer Intern",
        "applied_date" => "30-09-2026",
        "status" => "Pending"
    ],

    4 => [
        "name" => "Dhanush K",
        "email" => "dhanush@gmail.com",
        "college" => "Mahendra College of Engineering",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "29-09-2026",
        "status" => "Under Review"
    ],

    5 => [
        "name" => "Harini S",
        "email" => "harini@gmail.com",
        "college" => "Kongu Engineering College",
        "internship" => "PHP Web Development Intern",
        "applied_date" => "28-09-2026",
        "status" => "Shortlisted"
    ],

    6 => [
        "name" => "Vishal Kumar",
        "email" => "vishal@gmail.com",
        "college" => "Sri Krishna College",
        "internship" => "Web Development Intern",
        "applied_date" => "27-09-2026",
        "status" => "Selected"
    ],

    7 => [
        "name" => "Keerthana R",
        "email" => "keerthana@gmail.com",
        "college" => "PSG College of Technology",
        "internship" => "UI/UX Design Intern",
        "applied_date" => "26-09-2026",
        "status" => "Under Review"
    ],

    8 => [
        "name" => "Ajay Kumar",
        "email" => "ajay@gmail.com",
        "college" => "Coimbatore Institute of Technology",
        "internship" => "Cyber Security Intern",
        "applied_date" => "25-09-2026",
        "status" => "Rejected"
    ],

    9 => [
        "name" => "Divya M",
        "email" => "divya@gmail.com",
        "college" => "Kumaraguru College of Technology",
        "internship" => "Cloud Computing Intern",
        "applied_date" => "24-09-2026",
        "status" => "Shortlisted"
    ],

    10 => [
        "name" => "Kavin Raj",
        "email" => "kavin@gmail.com",
        "college" => "Coimbatore Engineering College",
        "internship" => "Full Stack Developer Intern",
        "applied_date" => "23-09-2026",
        "status" => "Pending"
    ]

];

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (
        isset($_POST["applicant_id"]) &&
        isset($_POST["action"])
    ) {

        $applicantId = $_POST["applicant_id"];
        $action = $_POST["action"];

        if ($action == "shortlist") {

            $message = "Applicant shortlisted successfully.";

        } elseif ($action == "select") {

            $message = "Applicant selected successfully.";

        } elseif ($action == "reject") {

            $message = "Applicant rejected successfully.";

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Applicants - Company</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f2f5f9;
}

header {
    background: #172B4D;
    color: white;
    text-align: center;
    padding: 25px;
}

header h1 {
    margin: 0;
}

header p {
    margin-bottom: 0;
}

nav {
    background: white;
    padding: 15px;
    text-align: center;
    box-shadow: 0 2px 6px #ccc;
}

nav a {
    color: #1f4e79;
    text-decoration: none;
    font-weight: bold;
    margin: 0 10px;
}

.container {
    width: 92%;
    max-width: 1200px;
    margin: 30px auto;
}

.title-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 10px #ddd;
    margin-bottom: 25px;
}

.title-box h2 {
    color: #1f4e79;
    margin-top: 0;
}

.search-form {
    display: flex;
    gap: 10px;
}

.search-form input {
    flex: 1;
    padding: 13px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

.search-form button {
    padding: 13px 22px;
    border: none;
    border-radius: 6px;
    background: #1f4e79;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

.message {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 14px;
    border-radius: 7px;
    margin-bottom: 20px;
}

.applicant-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.applicant-card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 10px #ddd;
}

.applicant-card h3 {
    color: #1f4e79;
    margin-top: 0;
}

.applicant-card p {
    color: #444;
    margin: 10px 0;
}

.status {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 20px;
    font-weight: bold;
}

.pending {
    background: #fff3cd;
    color: #856404;
}

.review {
    background: #e3f2fd;
    color: #1565c0;
}

.shortlisted {
    background: #e8f5e9;
    color: #2e7d32;
}

.selected {
    background: #d1f2eb;
    color: #00695c;
}

.rejected {
    background: #ffebee;
    color: #c62828;
}

.action-form {
    margin-top: 18px;
}

.action-form button {
    padding: 9px 14px;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
    margin-right: 5px;
    font-weight: bold;
}

.shortlist-btn {
    background: #2e7d32;
}

.select-btn {
    background: #00695c;
}

.reject-btn {
    background: #c62828;
}
.back {
    display: inline-block;
    margin-top: 25px;
    color: #1f4e79;
    text-decoration: none;
    font-weight: bold;
}

@media (max-width: 800px) {

    .applicant-grid {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 500px) {

    .search-form {
        flex-direction: column;
    }

    .search-form button {
        width: 100%;
    }

}

</style>

</head>


<body>


<header>

    <h1>🎓 Internship Portal</h1>

    <p>
        Company Panel -
        <?php echo htmlspecialchars($companyName); ?>
    </p>

</header>


<nav>

    <a href="dashboard.php">🏠 Dashboard</a>

    <a href="profile.php">🏢 Profile</a>

    <a href="add_internship.php">➕ Add Internship</a>

    <a href="internships.php">💼 My Internships</a>

    <a href="applicants.php">👥 Applicants</a>

    <a href="../logout.php">🚪 Logout</a>

</nav>


<div class="container">


    <div class="title-box">

        <h2>👥 Internship Applicants</h2>

        <p>
            View and manage students who applied for internships.
        </p>


        <form method="GET" class="search-form">

            <input
                type="text"
                name="search"
                placeholder="Search applicant, college or internship"
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <button type="submit">
                🔍 Search
            </button>

        </form>

    </div>


    <?php if ($message != "") { ?>

        <div class="message">

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php } ?>


    <div class="applicant-grid">

    <?php

    $found = false;

    foreach ($applicants as $id => $applicant) {

        if (
            $search == "" ||
            stripos($applicant["name"], $search) !== false ||
            stripos($applicant["email"], $search) !== false ||
            stripos($applicant["college"], $search) !== false ||
            stripos($applicant["internship"], $search) !== false
        ) {

            $found = true;

    ?>

        <div class="applicant-card">

            <h3>
                👤
                <?php
                echo htmlspecialchars($applicant["name"]);
                ?>
            </h3>

            <p>
                <strong>Email:</strong>
                <?php
                echo htmlspecialchars($applicant["email"]);
                ?>
            </p>

            <p>
                <strong>College:</strong>
                <?php
                echo htmlspecialchars($applicant["college"]);
                ?>
            </p>

            <p>
                <strong>Internship:</strong>
                <?php
                echo htmlspecialchars($applicant["internship"]);
                ?>
            </p>

            <p>
                <strong>Applied Date:</strong>
                <?php
                echo htmlspecialchars($applicant["applied_date"]);
                ?>
            </p>

            <p>
                <strong>Status:</strong>

                <?php

                if ($applicant["status"] == "Pending") {

                    echo '<span class="status pending">Pending</span>';

                } elseif ($applicant["status"] == "Under Review") {

                    echo '<span class="status review">Under Review</span>';

                } elseif ($applicant["status"] == "Shortlisted") {

                    echo '<span class="status shortlisted">Shortlisted</span>';

                } elseif ($applicant["status"] == "Selected") {

                    echo '<span class="status selected">Selected</span>';

                } elseif ($applicant["status"] == "Rejected") {

                    echo '<span class="status rejected">Rejected</span>';

                }

                ?>

            </p>


            <form method="POST" class="action-form">

                <input
                    type="hidden"
                    name="applicant_id"
                    value="<?php echo $id; ?>"
                >

                <button
                    type="submit"
                    name="action"
                    value="shortlist"
                    class="shortlist-btn"
                >
                    Shortlist
                </button>

                <button
                    type="submit"
                    name="action"
                    value="select"
                    class="select-btn"
                >
                    Select
                </button>

                <button
                    type="submit"
                    name="action"
                    value="reject"
                    class="reject-btn"
                >
                    Reject
                </button>

            </form>

        </div>

    <?php

        }

    }


    if (!$found) {

    ?>

        <div class="applicant-card">

            <h3>No Applicants Found</h3>

            <p>
                Try another search keyword.
            </p>

        </div>

    <?php

    }

    ?>

    </div>


    <a href="dashboard.php" class="back">
        ← Back to Company Dashboard
    </a>


</div>

</body>

</html>