<?php
session_start();

require_once "config/database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if ($name == "" || $email == "" || $password == "") {
        $message = "Please fill all fields.";
    } elseif (strlen($password) < 6) {
        $message = "Password must be at least 6 characters.";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $check = $conn->prepare(
            "SELECT id FROM users WHERE email = ?"
        );
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $message = "This email already exists.";
        } else {
            $role = "admin";

            $stmt = $conn->prepare(
                "INSERT INTO users (name, email, password, role)
                 VALUES (?, ?, ?, ?)"
            );

            $stmt->bind_param(
                "ssss",
                $name,
                $email,
                $hashedPassword,
                $role
            );

            if ($stmt->execute()) {
                $message = "Admin account created successfully. Please login.";
            } else {
                $message = "Error creating admin account.";
            }

            $stmt->close();
        }

        $check->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Setup Admin</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #eef3f8;
    margin: 0;
    padding: 30px 15px;
}
.container {
    max-width: 420px;
    margin: 40px auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 15px #ccc;
}
h2 {
    text-align: center;
    color: #1f4e79;
}
label {
    display: block;
    margin-top: 15px;
    font-weight: bold;
}
input {
    width: 100%;
    box-sizing: border-box;
    padding: 12px;
    margin-top: 7px;
    border: 1px solid #bbb;
    border-radius: 6px;
}
button {
    width: 100%;
    padding: 12px;
    margin-top: 20px;
    background: #1f4e79;
    color: white;
    border: 0;
    border-radius: 6px;
    cursor: pointer;
}
.message {
    padding: 10px;
    background: #e8f5e9;
    margin-top: 15px;
    overflow-wrap: anywhere;
}
</style>
</head>
<body>
<div class="container">
    <h2>Create Admin Account</h2>

    <?php if ($message != "") { ?>
        <div class="message">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php } ?>

    <form method="POST">
        <label>Admin Name</label>
        <input type="text" name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="password" minlength="6" required>

        <button type="submit">Create Admin</button>
    </form>

    <p style="text-align:center">
        <a href="login.php">Go to Login</a>
    </p>
</div>
</body>
</html>