<?php

$email = "";
$password = "";
$role = "";
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $role = $_POST["role"];

    /* Validate fields */

    if ($email == "" || $password == "" || $role == "") {

        $message = "Please fill all the fields.";

    } else {
        if ($role == "student") {

            header("Location: student/dashboard.php");
            exit();

        } elseif ($role == "company") {

            header("Location: company/dashboard.php");
            exit();

        } elseif ($role == "admin") {

            header("Location: admin/dashboard.php");
            exit();

        } else {

            $message = "Please select a valid role.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Login - Internship Portal</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #eef3f8;
        }

        header {
            background: #1f4e79;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
            font-size: 28px;
        }

        header p {
            margin: 8px 0 0;
        }

        .container {
            width: 100%;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
        }

        .login-box {
            background: white;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 4px 15px #ccc;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-bottom: 25px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        input,
        select {
            width: 100%;
            padding: 13px;
            margin-bottom: 20px;
            border: 1px solid #bbb;
            border-radius: 6px;
            font-size: 15px;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #1f4e79;
        }

        button {
            width: 100%;
            padding: 13px;
            background: #1f4e79;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #163b5c;
        }

        .message {
            background: #ffebee;
            color: #c62828;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 6px;
            text-align: center;
        }

        .links {
            text-align: center;
            margin-top: 20px;
        }

        .links a {
            color: #1f4e79;
            text-decoration: none;
            font-weight: bold;
        }

        .links a:hover {
            text-decoration: underline;
        }

    </style>

</head>

<body>

<header>

    <h1>🎓 Internship Portal</h1>

    <p>College Internship Application Portal</p>

</header>


<div class="container">

    <div class="login-box">

        <h2>Login</h2>

        <?php if ($message != "") { ?>

            <div class="message">

                <?php
                echo htmlspecialchars($message);
                ?>

            </div>

        <?php } ?>


        <form method="POST" action="">

            <label>Email</label>

            <input
                type="email"
                name="email"
                placeholder="Enter your email"
                value="<?php echo htmlspecialchars($email); ?>"
                required
            >


            <label>Password</label>

            <input
                type="password"
                name="password"
                placeholder="Enter your password"
                required
            >


            <label>Login As</label>

            <select name="role" required>

                <option value="">Select Role</option>

                <option value="student"
                    <?php
                    if ($role == "student") echo "selected";
                    ?>>
                    Student
                </option>

                <option value="company"
                    <?php
                    if ($role == "company") echo "selected";
                    ?>>
                    Company
                </option>

                <option value="admin"
                    <?php
                    if ($role == "admin") echo "selected";
                    ?>>
                    Admin
                </option>

            </select>


            <button type="submit">
                🔐 Login
            </button>

        </form>


        <div class="links">

            <p>
                Don't have an account?
                <a href="register.php">Create Account</a>
            </p>

            <p>
                <a href="index.php">← Back to Home</a>
            </p>

        </div>

    </div>

</div>

</body>

</html>