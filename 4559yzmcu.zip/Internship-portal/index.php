<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>College Internship Application Portal</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f7ff;
            color: #172033;
        }

        a {
            text-decoration: none;
}

        .navbar {
            background: white;
            height: 75px;
            padding: 0 8%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .logo {
            font-size: 22px;
            font-weight: bold;
            color: #3156d3;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .nav-links a {
            color: #333;
            font-weight: 600;
        }

        .btn {
            background: #3156d3;
            color: white !important;
            padding: 12px 22px;
            border-radius: 8px;
            display: inline-block;
            font-weight: bold;
        }

        .btn:hover {
            background: #2444b5;
        }

        .outline {
            background: white;
            color: #3156d3 !important;
            border: 2px solid #3156d3;
        }

        .hero {
            min-height: 520px;
            padding: 70px 9%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 50px;
            background: linear-gradient(135deg, #eef2ff, #ffffff);
        }

        .hero-content {
            max-width: 650px;
        }

        .tag {
            color: #3156d3;
            font-size: 13px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        .hero h1 {
            font-size: 52px;
            line-height: 1.15;
            margin: 20px 0;
        }

        .hero h1 span {
            color: #3156d3;
        }

        .hero p {
            font-size: 18px;
            line-height: 1.6;
            color: #687386;
        }

        .buttons {
            margin-top: 30px;
            display: flex;
            gap: 15px;
}
        .hero-card {
            width: 330px;
            background: white;
            padding: 40px;
            text-align: center;
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(49,86,211,0.15);
        }

        .hero-icon {
            font-size: 65px;
            margin-bottom: 20px;
        }

        .hero-card h2 {
            margin-bottom: 12px;
        }

        .section {
            padding: 70px 8%;
        }

        .section-title {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            background: white;
            padding: 28px;
            border-radius: 15px;
            border: 1px solid #e3e7ef;
        }

        .number {
            color: #3156d3;
            font-size: 22px;
            font-weight: bold;
        }

        .card h3 {
            margin: 15px 0 10px;
        }

        .card p {
            color: #687386;
            line-height: 1.5;
        }

        .stats {
            background: #3156d3;
            color: white;
            padding: 40px 10%;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            text-align: center;
        }

        .stats h2 {
            font-size: 30px;
        }

        .stats p {
            margin-top: 8px;
        }
        footer {
            background: white;
            text-align: center;
            padding: 25px;
            color: #687386;
        }
        @media(max-width: 800px) {

            .hero {
                flex-direction: column;
            }

            .hero h1 {
                font-size: 40px;
            }

            .cards {
                grid-template-columns: 1fr 1fr;
            }

            .stats {
                grid-template-columns: 1fr 1fr;
                gap: 25px;
            }

            .nav-links a:not(.btn) {
                display: none;
            }

        }

    </style>

</head>


             <body>

    <header class="navbar">

        <div class="logo">
            🎓 Internship Portal
        </div>

        <div class="nav-links">

            <a href="index.php">Home</a>

            <a href="student/internships.php">
                Internships
            </a>

            <a href="login.php">
                Login
            </a>

            <a href="register.php" class="btn">
                Register
            </a>

        </div>

    </header>
    <section class="hero">

        <div class="hero-content">

            <div class="tag">
                COLLEGE INTERNSHIP APPLICATION PORTAL
            </div>

            <h1>
                Find the Right Internship.
                <span>Build Your Future.</span>
            </h1>

            <p>
                A simple platform for students to discover internships,
                apply online and track their applications.
            </p>

            <div class="buttons">

                <a href="student/internships.php" class="btn">
                    Explore Internships
                </a>

                <a href="register.php" class="btn outline">
                    Create Account
                </a>

            </div>

        </div>


        <div class="hero-card">

            <div class="hero-icon">
                💼
            </div>

            <h2>
                Career Opportunities
            </h2>

            <p>
                Connect students with companies and meaningful
                internship opportunities.
            </p>

        </div>

    </section>

    <section class="section">

        <h2 class="section-title">
            How It Works
        </h2>

        <div class="cards">

            <div class="card">

                <div class="number">01</div>

                <h3>
                    Create Profile
                </h3>

                <p>
                    Register and add your education and skills.
                </p>

            </div>


            <div class="card">

                <div class="number">02</div>

                <h3>
                    Find Internship
                </h3>

                <p>
                    Search internship opportunities based on your interests.
                </p>

            </div>


            <div class="card">

                <div class="number">03</div>

                <h3>
                    Apply Online
                </h3>

                <p>
                    Submit your internship application easily.
                </p>

            </div>


            <div class="card">

                <div class="number">04</div>

                <h3>
                    Track Status
                </h3>

                <p>
                    Check your application status anytime.
                </p>

            </div>

        </div>

    </section>

    <section class="stats">

        <div>
            <h2>50+</h2>
            <p>Internships</p>
        </div>

        <div>
            <h2>25+</h2>
            <p>Companies</p>
        </div>

        <div>
            <h2>100+</h2>
            <p>Students</p>
        </div>

        <div>
            <h2>24/7</h2>
            <p>Access</p>
        </div>

    </section>
    <footer>

        © 2026 College Internship Application Portal

    </footer>


</body>

</html>