<?php

session_start();


if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "admin";
}
$applications = [

    1 => [
        "student" => "Haseen R",
        "email" => "haseenrafi12@gmail.com",
        "internship" => "PHP Web Development Intern",
        "company" => "Tech Solutions",
        "date" => "05-10-2026",
        "status" => "Under Review"
    ],

    2 => [
        "student" => "Geetha Varshini R",
        "email" => "geethavarshini2711@gmail.com",
        "internship" => "Python Developer Intern",
        "company" => "Innovate Labs",
        "date" => "04-10-2026",
        "status" => "Shortlisted"
    ],

    3 => [
        "student" => "Abirami R",
        "email" => "abiramiravi1767@gmail.com",
        "internship" => "UI/UX Design Intern",
        "company" => "Digital Works",
        "date" => "03-10-2026",
        "status" => "Rejected"
    ],
    
    4 => [
        "student" => "Dhanusha K",
        "email" => "dhanusha34576@gmail.com",
        "internship" => "Java Developer Intern",
        "company" => "CodeCraft Technologies",
        "date" => "02-10-2026",
        "status" => "Under Review"
    ],

    5 => [
        "student" => "Dhanishka S",
        "email" => "dhanishkas28@gmail.com",
        "internship" => "Data Science Intern",
        "company" => "DataVision Analytics",
        "date" => "01-10-2026",
        "status" => "Shortlisted"
    ],

    6 => [
        "student" => "Vishal Kumar",
        "email" => "vishal@gmail.com",
        "internship" => "Machine Learning Intern",
        "company" => "AI Future Labs",
        "date" => "30-09-2026",
        "status" => "Selected"
    ],

    7 => [
        "student" => "Keerthana R",
        "email" => "keerthana@gmail.com",
        "internship" => "Web Designer Intern",
        "company" => "Creative Minds",
        "date" => "29-09-2026",
        "status" => "Under Review"
    ],

    8 => [
        "student" => "Ajay Kumar",
        "email" => "ajay@gmail.com",
        "internship" => "Cyber Security Intern",
        "company" => "SecureNet Solutions",
        "date" => "28-09-2026",
        "status" => "Rejected"
    ],

    9 => [
        "student" => "Divya M",
        "email" => "divya@gmail.com",
        "internship" => "Cloud Computing Intern",
        "company" => "CloudTech Services",
        "date" => "27-09-2026",
        "status" => "Shortlisted"
    ],

    10 => [
        "student" => "Kavin Raj",
        "email" => "kavinraj@gmail.com",
        "internship" => "Full Stack Developer Intern",
        "company" => "NextGen Technologies",
        "date" => "26-09-2026",
        "status" => "Under Review"
    ]


];


$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}


$statusFilter = "";

if (isset($_GET["status"])) {
    $statusFilter = $_GET["status"];
}


$filteredApplications = [];

foreach ($applications as $id => $application) {

    $searchMatch =
        $search == "" ||
        stripos($application["student"], $search) !== false ||
        stripos($application["email"], $search) !== false ||
        stripos($application["internship"], $search) !== false ||
        stripos($application["company"], $search) !== false;

    $statusMatch =
        $statusFilter == "" ||
        $application["status"] == $statusFilter;

    if ($searchMatch && $statusMatch) {
        $filteredApplications[$id] = $application;
    }
}
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $applicationId = (int)$_POST["application_id"];
    $newStatus = $_POST["status"];

    if (isset($applications[$applicationId])) {

        $message =
            "Application of " .
            $applications[$applicationId]["student"] .
            " updated to " .
            $newStatus .
            ".";

    } else {

        $message = "Application not found.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Manage Applications</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #eef3f8;
        }

        header {
            background: #5B2C83;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 30px auto;
        }

        .filter-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .filter-box input,
        .filter-box select {
            padding: 11px;
            border: 1px solid #bbb;
            border-radius: 6px;
            margin-right: 8px;
        }

        .filter-box input {
            width: 45%;
        }

        .filter-box button {
            padding: 11px 18px;
            background: #5B2C83;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px #ccc;
        }

        .card h2 {
            color: #1f4e79;
        }

        .status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 5px;
            font-weight: bold;
        }

        .review {
            background: #fff3cd;
            color: #856404;
        }

        .shortlisted {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .rejected {
            background: #ffebee;
            color: #c62828;
        }

        .selected {
            background: #d1ecf1;
            color: #0c5460;
        }

        .update-form {
            margin-top: 18px;
        }

        .update-form select {
            padding: 10px;
            border: 1px solid #bbb;
            border-radius: 5px;
        }

        .update-form button {
            padding: 10px 15px;
            background: #5B2C;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .back {
            display: inline-block;
            margin-top: 10px;
            color: #1f4e79;
            text-decoration: none;
            font-weight: bold;
        }

        .no-result {
            background: white;
            padding: 30px;
            text-align: center;
            border-radius: 10px;
        }

    </style>

</head>

<body>

<header>

    <h1>⚙️ Admin Portal</h1>

    <p>Manage Applications</p>

</header>

<div class="container">

    <h2>Application Management</h2>

    <?php if ($message != "") { ?>

        <div class="message">

            <?php
            echo htmlspecialchars($message);
            ?>

        </div>

    <?php } ?>

    <div class="filter-box">

        <form method="GET" action="">

            <input
                type="text"
                name="search"
                placeholder="Search student, company or internship..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <select name="status">

                <option value="">All Status</option>

                <option value="Under Review"
                    <?php
                    if ($statusFilter == "Under Review")
                        echo "selected";
                    ?>>
                    Under Review
                </option>

                <option value="Shortlisted"
                    <?php
                    if ($statusFilter == "Shortlisted")
                        echo "selected";
                    ?>>
                    Shortlisted
                </option>

                <option value="Selected"
                    <?php
                    if ($statusFilter == "Selected")
                        echo "selected";
                    ?>>
                    Selected
                </option>

                <option value="Rejected"
                    <?php
                    if ($statusFilter == "Rejected")
                        echo "selected";
                    ?>>
                    Rejected
                </option>

            </select>

            <button type="submit">
                🔍 Filter
            </button>

        </form>

    </div>


    

    <?php if (count($filteredApplications) > 0) { ?>

        <?php foreach ($filteredApplications as $id => $application) { ?>

            <div class="card">

                <h2>
                    <?php
                    echo htmlspecialchars($application["student"]);
                    ?>
                </h2>

                <p>
                    <b>Email:</b>
                    <?php
                    echo htmlspecialchars($application["email"]);
                    ?>
                </p>

                <p>
                    <b>Internship:</b>
                    <?php
                    echo htmlspecialchars($application["internship"]);
                    ?>
                </p>

                <p>
                    <b>Company:</b>
                    <?php
                    echo htmlspecialchars($application["company"]);
                    ?>
                </p>

                <p>
                    <b>Applied Date:</b>
                    <?php
                    echo htmlspecialchars($application["date"]);
                    ?>
                </p>

                <p>

                    <b>Status:</b>

                    <span class="status

                    <?php

                    if ($application["status"] == "Under Review") {

                        echo "review";

                    } elseif ($application["status"] == "Shortlisted") {

                        echo "shortlisted";

                    } elseif ($application["status"] == "Rejected") {

                        echo "rejected";

                    } elseif ($application["status"] == "Selected") {

                        echo "selected";
                    }

                    ?>">

                        <?php
                        echo htmlspecialchars($application["status"]);
                        ?>

                    </span>

                </p>
                 <form
                    method="POST"
                    action=""
                    class="update-form"
                >

                    <input
                        type="hidden"
                        name="application_id"
                        value="<?php echo $id; ?>"
                    >

                    <select name="status">

                        <option value="Under Review">
                            Under Review
                        </option>

                        <option value="Shortlisted">
                            Shortlisted
                        </option>

                        <option value="Selected">
                            Selected
                        </option>

                        <option value="Rejected">
                            Rejected
                        </option>

                    </select>

                    <button type="submit">
                        Update Status
                    </button>

                </form>

            </div>

        <?php } ?>

    <?php } else { ?>

        <div class="no-result">

            <h2>No Applications Found</h2>

            <p>
                Try another search or status.
            </p>

        </div>

    <?php } ?>


    <a class="back" href="dashboard.php">
        ← Back to Admin Dashboard
    </a>

</div>

</body>

</html>