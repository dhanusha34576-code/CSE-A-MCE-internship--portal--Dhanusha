<?php

session_start();

$adminName = "Administrator";
$userRole = "Admin";

$internships = [
    1 => [
        "title" => "PHP Web Development Intern",
        "company" => "Tech Solutions",
        "location" => "Chennai",
        "duration" => "3 Months",
        "applicants" => 8,
        "status" => "Active"
    ],

    2 => [
        "title" => "Python Developer Intern",
        "company" => "Innovate Labs",
        "location" => "Bangalore",
        "duration" => "3 Months",
        "applicants" => 5,
        "status" => "Active"
    ],

    3 => [
        "title" => "UI/UX Design Intern",
        "company" => "Digital Works",
        "location" => "Chennai",
        "duration" => "2 Months",
        "applicants" => 3,
        "status" => "Closed"
    ],

    4 => [
        "title" => "Java Developer Intern",
        "company" => "CodeCraft Technologies",
        "location" => "Coimbatore",
        "duration" => "3 Months",
        "applicants" => 6,
        "status" => "Active"
    ],

    5 => [
        "title" => "Data Science Intern",
        "company" => "DataVision Analytics",
        "location" => "Hyderabad",
        "duration" => "4 Months",
        "applicants" => 9,
        "status" => "Active"
    ],

    6 => [
        "title" => "Machine Learning Intern",
        "company" => "AI Future Labs",
        "location" => "Bangalore",
        "duration" => "6 Months",
        "applicants" => 12,
        "status" => "Active"
    ],

    7 => [
        "title" => "Web Designer Intern",
        "company" => "Creative Minds",
        "location" => "Chennai",
        "duration" => "2 Months",
        "applicants" => 4,
        "status" => "Active"
    ],

    8 => [
        "title" => "Cyber Security Intern",
        "company" => "SecureNet Solutions",
        "location" => "Bangalore",
        "duration" => "3 Months",
        "applicants" => 7,
        "status" => "Active"
    ],

    9 => [
        "title" => "Cloud Computing Intern",
        "company" => "CloudTech Services",
        "location" => "Hyderabad",
        "duration" => "3 Months",
        "applicants" => 10,
        "status" => "Active"
    ],

    10 => [
        "title" => "Mobile App Development Intern",
        "company" => "AppWorks India",
        "location" => "Coimbatore",
        "duration" => "4 Months",
        "applicants" => 5,
        "status" => "Active"
    ],

    11 => [
        "title" => "Full Stack Developer Intern",
        "company" => "NextGen Technologies",
        "location" => "Chennai",
        "duration" => "6 Months",
        "applicants" => 11,
        "status" => "Active"
    ]
];

$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (isset($_POST["internship_id"], $_POST["action"])) {

        $internshipId = (int) $_POST["internship_id"];
        $action = $_POST["action"];

        if (isset($internships[$internshipId])) {

            if ($action === "close") {

                $internships[$internshipId]["status"] = "Closed";

                $message = "Internship ID " . $internshipId . " has been closed successfully.";

            } elseif ($action === "activate") {

                $internships[$internshipId]["status"] = "Active";

                $message = "Internship ID " . $internshipId . " has been activated successfully.";

            } else {

                $message = "Invalid action.";

            }

        } else {

            $message = "Internship not found.";

        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin - Manage Internships</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f2f5f9;
}

header {
    background: #5B2C83;
    color: white;
    padding: 25px;
    text-align: center;
}

header h1 {
    margin: 0;
    font-size: 30px;
}

header p {
    margin-top: 8px;
}
nav {
    background: white;
    padding: 15px;
    text-align: center;
    box-shadow: 0 2px 6px #ccc;
}

nav a {
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
    margin: 0 10px;
}

nav a:hover {
    color: #000;
}

.container {
    width: 92%;
    max-width: 1200px;
    margin: 30px auto;
}

.title-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 3px 10px #ddd;
}

.title-box h2 {
    color: #5B2C83;
    margin-top: 0;
}

.search-form {
    display: flex;
    gap: 10px;
}

.search-form input {
    flex: 1;
    padding: 13px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

.search-form button {
    padding: 13px 22px;
    background: #1f4e79;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}

.search-form button:hover {
    background: #5B2C83;
}

.message {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 14px;
    border-radius: 7px;
    margin-bottom: 20px;
    font-weight: bold;
}

.internship-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.internship-card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 10px #ddd;
}

.internship-card h3 {
    color: #5B2C83;
    margin-top: 0;
    font-size: 21px;
}

.internship-card p {
    margin: 10px 0;
    color: #444;
}

.status {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 20px;
    font-weight: bold;
}

.active {
    background: #d9f7df;
    color: #238636;
}

.closed {
    background: #ffe0e0;
    color: #c62828;
}

.action-form {
    margin-top: 18px;
}

.action-form button {
    padding: 10px 16px;
    border: none;
    border-radius: 6px;
    color: white;
    cursor: pointer;
    font-weight: bold;
}

.close-btn {
    background: #c62828;
}

.close-btn:hover {
    background: #a51f1f;
}

.activate-btn {
    background: #2e7d32;
}

.activate-btn:hover {
    background: #1b5e20;
}

.back {
    display: inline-block;
    margin-top: 25px;
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
}

.back:hover {
    color: #000;
}

@media (max-width: 800px) {

    .internship-grid {
        grid-template-columns: 1fr;
    }

    nav a {
        display: inline-block;
        margin: 8px;
    }
}


@media (max-width: 500px) {

    .search-form {
        flex-direction: column;
    }

    .search-form button {
        width: 100%;
    }

}

</style>

</head>


<body>

<header>

    <h1>🎓 Internship Portal</h1>

    <p>
        Admin Panel -
        <?php echo htmlspecialchars($adminName); ?>
    </p>

</header>

<nav>

    <a href="dashboard.php">
        🏠 Dashboard
    </a>

    <a href="students.php">
        👨‍🎓 Students
    </a>

    <a href="companies.php">
        🏢 Companies
    </a>

    <a href="internships.php">
        💼 Internships
    </a>

    <a href="application.php">
        📄 Applications
    </a>

    <a href="../logout.php">
        🚪 Logout
    </a>

</nav>

<div class="container">

    <div class="title-box">

        <h2>
            💼 Manage Internships
        </h2>

        <p>
            Admin can view, search and manage all internship opportunities.
        </p>


        <form method="GET" class="search-form">

            <input
                type="text"
                name="search"
                placeholder="Search internship, company or location..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <button type="submit">
                🔍 Search
            </button>

        </form>

    </div>

    <?php if ($message !== ""): ?>

        <div class="message">
            <?php echo htmlspecialchars($message); ?>
        </div>

    <?php endif; ?>

    <div class="internship-grid">

    <?php

    $found = false;

    foreach ($internships as $id => $internship):

        if (
            $search !== "" &&
            stripos($internship["title"], $search) === false &&
            stripos($internship["company"], $search) === false &&
            stripos($internship["location"], $search) === false
        ) {
            continue;
        }

        $found = true;

    ?>

        <div class="internship-card">

            <h3>
                💼
                <?php echo htmlspecialchars($internship["title"]); ?>
            </h3>


            <p>

                <strong>
                    🏢 Company:
                </strong>

                <?php echo htmlspecialchars($internship["company"]); ?>

            </p>


            <p>

                <strong>
                    📍 Location:
                </strong>

                <?php echo htmlspecialchars($internship["location"]); ?>

            </p>


            <p>

                <strong>
                    ⏳ Duration:
                </strong>

                <?php echo htmlspecialchars($internship["duration"]); ?>

            </p>


            <p>

                <strong>
                    👥 Applicants:
                </strong>

                <?php echo (int) $internship["applicants"]; ?>

            </p>


            <p>

                <strong>
                    Status:
                </strong>


                <?php if ($internship["status"] === "Active"): ?>

                    <span class="status active">
                        Active
                    </span>

                <?php else: ?>

                    <span class="status closed">
                        Closed
                    </span>

                <?php endif; ?>

            </p>

            <form
                method="POST"
                class="action-form"
            >

                <input
                    type="hidden"
                    name="internship_id"
                    value="<?php echo (int) $id; ?>"
                >


                <?php if ($internship["status"] === "Active"): ?>

                    <button
                        type="submit"
                        name="action"
                        value="close"
                        class="close-btn"
                    >
                        Close Internship
                    </button>

                <?php else: ?>

                    <button
                        type="submit"
                        name="action"
                        value="activate"
                        class="activate-btn"
                    >
                        Activate Internship
                    </button>

                <?php endif; ?>

            </form>

        </div>


    <?php endforeach; ?>

    <?php if (!$found): ?>

        <div class="internship-card">

            <h3>
                No Internships Found
            </h3>

            <p>
                Try another search keyword.
            </p>

        </div>

    <?php endif; ?>

    </div>

    <a
        href="dashboard.php"
        class="back"
    >
        ← Back to Admin Dashboard
    </a>


</div>


</body>

</html>