<?php
session_start();


$adminName = "Administrator";


$companies = [
    [
        "id" => 1,
        "name" => "Tech Solutions",
        "email" => "techsolutions@gmail.com",
        "phone" => "9876543210",
        "location" => "Chennai",
        "internships" => 5,
        "status" => "Active"
    ],
    [
        "id" => 2,
        "name" => "Innovate Labs",
        "email" => "innovatelabs@gmail.com",
        "phone" => "9876543211",
        "location" => "Bangalore",
        "internships" => 8,
        "status" => "Active"
    ],
    [
        "id" => 3,
        "name" => "Digital Works",
        "email" => "digitalworks@gmail.com",
        "phone" => "9876543212",
        "location" => "Coimbatore",
        "internships" => 3,
        "status" => "Inactive"
    ],
    [
    "id" => 4,
    "name" => "CodeCraft Technologies",
    "email" => "codecraft@gmail.com",
    "phone" => "9876543213",
    "location" => "Coimbatore",
    "internships" => 4,
    "status" => "Active"
],

[
    "id" => 5,
    "name" => "DataVision Analytics",
    "email" => "datavision@gmail.com",
    "phone" => "9876543214",
    "location" => "Hyderabad",
    "internships" => 6,
    "status" => "Active"
],

[
    "id" => 6,
    "name" => "AI Future Labs",
    "email" => "aifuture@gmail.com",
    "phone" => "9876543215",
    "location" => "Bangalore",
    "internships" => 5,
    "status" => "Active"
],

[
    "id" => 7,
    "name" => "Creative Minds",
    "email" => "creativeminds@gmail.com",
    "phone" => "9876543216",
    "location" => "Chennai",
    "internships" => 3,
    "status" => "Active"
],

[
    "id" => 8,
    "name" => "SecureNet Solutions",
    "email" => "securenet@gmail.com",
    "phone" => "9876543217",
    "location" => "Bangalore",
    "internships" => 4,
    "status" => "Active"
],

[
    "id" => 9,
    "name" => "CloudTech Services",
    "email" => "cloudtech@gmail.com",
    "phone" => "9876543218",
    "location" => "Hyderabad",
    "internships" => 7,
    "status" => "Active"
],

[
    "id" => 10,
    "name" => "NextGen Technologies",
    "email" => "nextgen@gmail.com",
    "phone" => "9876543219",
    "location" => "Chennai",
    "internships" => 5,
    "status" => "Inactive"
]

];


$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}


$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $companyId = $_POST["company_id"];
    $action = $_POST["action"];

    if ($action == "activate") {
        $message = "Company ID $companyId has been activated.";
    } elseif ($action == "deactivate") {
        $message = "Company ID $companyId has been deactivated.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<title>Manage Companies</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f2f5f9;
}

header {
    background: #5B2C83;
    color: white;
    padding: 20px;
    text-align: center;
}

header h1 {
    margin: 0;
}

nav {
    background: white;
    padding: 15px;
    box-shadow: 0 2px 5px #ccc;
}

nav a {
    text-decoration: none;
    color: #1d1b1f;
    font-weight: bold;
    margin-right: 18px;
}

.container {
    width: 90%;
    max-width: 1100px;
    margin: 30px auto;
}

.search-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
}

.search-box h2 {
    color: #5B2C83;
}

.search-form {
    display: flex;
    gap: 10px;
}

.search-form input {
    flex: 1;
    padding: 12px;
    border: 1px solid #bbb;
    border-radius: 6px;
}

.search-form button {
    padding: 12px 20px;
    background: #1f4e79;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.message {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 12px;
    border-radius: 6px;
    margin-bottom: 20px;
}

.company-card {
    background: white;
    padding: 22px;
    margin-bottom: 18px;
    border-radius: 10px;
    box-shadow: 0 3px 10px #ddd;
}

.company-card h3 {
    color: #1f4e79;
    margin-top: 0;
}

.company-card p {
    margin: 9px 0;
}

.status {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 20px;
    font-weight: bold;
}

.active {
    background: #d9f7df;
    color: #238636;
}

.inactive {
    background: #ffe0e0;
    color: #c62828;
}

.action-form {
    margin-top: 15px;
}

.action-form button {
    padding: 9px 15px;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
}

.activate {
    background: #2e7d32;
}

.deactivate {
    background: #c62828;
}

.back {
    display: inline-block;
    margin-top: 10px;
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
}

</style>

</head>

<body>

<header>

<h1>🏢 Manage Companies</h1>

<p>Admin Panel - <?php echo $adminName; ?></p>

</header>


<nav>

<a href="dashboard.php">Dashboard</a>

<a href="students.php">Students</a>

<a href="companies.php">Companies</a>

<a href="internships.php">Internships</a>

<a href="application.php">Applications</a>

<a href="../logout.php">Logout</a>

</nav>


<div class="container">

<div class="search-box">

<h2>Company Management</h2>

<form method="GET" class="search-form">

<input
    type="text"
    name="search"
    placeholder="Search company name, email or location..."
    value="<?php echo htmlspecialchars($search); ?>"
>

<button type="submit">
🔍 Search
</button>

</form>

</div>


<?php if ($message != "") { ?>

<div class="message">

<?php echo htmlspecialchars($message); ?>

</div>

<?php } ?>


<?php

$found = false;

foreach ($companies as $company) {

    if (
        $search == "" ||
        stripos($company["name"], $search) !== false ||
        stripos($company["email"], $search) !== false ||
        stripos($company["location"], $search) !== false
    ) {

        $found = true;

?>

<div class="company-card">

<h3>
🏢 <?php echo htmlspecialchars($company["name"]); ?>
</h3>

<p>
<strong>Email:</strong>
<?php echo htmlspecialchars($company["email"]); ?>
</p>

<p>
<strong>Phone:</strong>
<?php echo htmlspecialchars($company["phone"]); ?>
</p>

<p>
<strong>Location:</strong>
<?php echo htmlspecialchars($company["location"]); ?>
</p>

<p>
<strong>Total Internships:</strong>
<?php echo $company["internships"]; ?>
</p>

<p>

<strong>Status:</strong>

<?php if ($company["status"] == "Active") { ?>

<span class="status active">
Active
</span>

<?php } else { ?>

<span class="status inactive">
Inactive
</span>

<?php } ?>

</p>


<form method="POST" class="action-form">

<input
    type="hidden"
    name="company_id"
    value="<?php echo $company["id"]; ?>"
>

<?php if ($company["status"] == "Active") { ?>

<button
    type="submit"
    name="action"
    value="deactivate"
    class="deactivate"
>
Deactivate
</button>

<?php } else { ?>

<button
    type="submit"
    name="action"
    value="activate"
    class="activate"
>
Activate
</button>

<?php } ?>

</form>

</div>

<?php

    }
}

if (!$found) {

    echo "<div class='company-card'>";
    echo "<p>No companies found.</p>";
    echo "</div>";

}

?>


<a href="dashboard.php" class="back">
← Back to Admin Dashboard
</a>

</div>

</body>

</html>