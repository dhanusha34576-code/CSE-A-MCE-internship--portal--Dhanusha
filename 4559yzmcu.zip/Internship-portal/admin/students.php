<?php
session_start();
$adminName = "Administrator";
$students = [
    [
        "id" => 1,
        "name" => "Haseen R",
        "email" => "haseenrafi12@gmail.com",
        "college" => "Mahendra Engineering College",
        "course" => "B.Tech IT",
        "status" => "Active"
    ],
    [
        "id" => 2,
        "name" => "Geethavarshini R",
        "email" => "priya@gmail.com",
        "college" => "ABC Engineering College",
        "course" => "B.E CSE",
        "status" => "Active"
    ],
    [
        "id" => 3,
        "name" => "Rahul M",
        "email" => "rahul@gmail.com",
        "college" => "XYZ College",
        "course" => "B.Tech AI & DS",
        "status" => "Inactive"
    ],
    [
        "id" => 4,
        "name" => "Dhanusha K",   
        "email" => "dhanusha34576@gmail.com",
        "college" => "Mahendra college of engineering",
        "course" => "B.Tech CSE",
        "status" => "Active"
    ],
        [
    "id" => 5,
    "name" => "Kavin Raj",
    "email" => "kavinraj@gmail.com",
    "college" => "Mahendra College of Engineering",
    "course" => "B.Tech CSE",
    "status" => "Active"
],

[
    "id" => 6,
    "name" => "Harini S",
    "email" => "harini@gmail.com",
    "college" => "Kongu Engineering College",
    "course" => "B.E CSE",
    "status" => "Active"
],

[
    "id" => 7,
    "name" => "Vishal Kumar",
    "email" => "vishal@gmail.com",
    "college" => "Sri Krishna College",
    "course" => "B.Tech IT",
    "status" => "Active"
],

[
    "id" => 8,
    "name" => "Keerthana R",
    "email" => "keerthana@gmail.com",
    "college" => "PSG College of Technology",
    "course" => "B.Tech AI & DS",
    "status" => "Active"
],

[
    "id" => 9,
    "name" => "Ajay Kumar",
    "email" => "ajay@gmail.com",
    "college" => "Coimbatore Institute of Technology",
    "course" => "B.E ECE",
    "status" => "Inactive"
],

[
    "id" => 10,
    "name" => "Divya M",
    "email" => "divya@gmail.com",
    "college" => "Kumaraguru College of Technology",
    "course" => "B.Tech IT",
    "status" => "Active"
]
];
$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $studentId = $_POST["student_id"];
    $action = $_POST["action"];

    if ($action == "activate") {
        $message = "Student ID $studentId has been activated.";
    } elseif ($action == "deactivate") {
        $message = "Student ID $studentId has been deactivated.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Manage Students</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f2f5f9;
        }

        header {
            background: #5B2C83;
            color: white;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        nav {
            background: white;
            padding: 15px;
            box-shadow: 0 2px 5px #ccc;
        }

        nav a {
            text-decoration: none;
            color: #485663;
            font-weight: bold;
            margin-right: 18px;
        }

        .container {
            width: 90%;
            max-width: 1100px;
            margin: 30px auto;
        }

        .top-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .top-box h2 {
            color: #103557;
        }

        .search-form {
            display: flex;
            gap: 10px;
        }

        .search-form input {
            flex: 1;
            padding: 12px;
            border: 1px solid #bbb;
            border-radius: 6px;
        }

        .search-form button {
            padding: 12px 20px;
            background: #5B2C83;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .student-card {
            background: white;
            padding: 22px;
            margin-bottom: 18px;
            border-radius: 10px;
            box-shadow: 0 3px 10px #ddd;
        }

        .student-card h3 {
            color: rgba(232, 103, 11, 0.8);
            margin-top: 0;
        }

        .student-card p {
            margin: 8px 0;
        }

        .status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: bold;
        }

        .active {
            background: #d9f7df;
            color: #238636;
        }

        .inactive {
            background: #ffe0e0;
            color: #c62828;
        }

        .action-form {
            margin-top: 15px;
        }

        .action-form button {
            padding: 9px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: white;
        }

        .activate {
            background: #2e7d32;
        }

        .deactivate {
            background: #c62828;
        }

        .back {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #1f4e79;
            font-weight: bold;
        }

    </style>

</head>

<body>

<header>

    <h1>🎓 Manage Students</h1>

    <p>Admin Panel - <?php echo $adminName; ?></p>

</header>


<nav>

    <a href="dashboard.php">Dashboard</a>

    <a href="students.php">Students</a>

    <a href="companies.php">Companies</a>

    <a href="internships.php">Internships</a>

    <a href="application.php">Applications</a>

    <a href="../logout.php">Logout</a>

</nav>


<div class="container">

    <div class="top-box">

        <h2>Student Management</h2>

        <form method="GET" class="search-form">

            <input
                type="text"
                name="search"
                placeholder="Search student name, email or college..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <button type="submit">🔍 Search</button>

        </form>

    </div>


    <?php if ($message != "") { ?>

        <div class="message">

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php } ?>


    <?php

    $found = false;

    foreach ($students as $student) {

        if (
            $search == "" ||
            stripos($student["name"], $search) !== false ||
            stripos($student["email"], $search) !== false ||
            stripos($student["college"], $search) !== false
        ) {

            $found = true;

    ?>

        <div class="student-card">

            <h3>
                👨‍🎓 <?php echo htmlspecialchars($student["name"]); ?>
            </h3>

            <p>
                <strong>Email:</strong>
                <?php echo htmlspecialchars($student["email"]); ?>
            </p>

            <p>
                <strong>College:</strong>
                <?php echo htmlspecialchars($student["college"]); ?>
            </p>

            <p>
                <strong>Course:</strong>
                <?php echo htmlspecialchars($student["course"]); ?>
            </p>

            <p>
                <strong>Status:</strong>

                <?php if ($student["status"] == "Active") { ?>

                    <span class="status active">
                        Active
                    </span>

                <?php } else { ?>

                    <span class="status inactive">
                        Inactive
                    </span>

                <?php } ?>

            </p>


            <form method="POST" class="action-form">

                <input
                    type="hidden"
                    name="student_id"
                    value="<?php echo $student["id"]; ?>"
                >

                <?php if ($student["status"] == "Active") { ?>

                    <button
                        type="submit"
                        name="action"
                        value="deactivate"
                        class="deactivate"
                    >
                        Deactivate
                    </button>

                <?php } else { ?>

                    <button
                        type="submit"
                        name="action"
                        value="activate"
                        class="activate"
                    >
                        Activate
                    </button>

                <?php } ?>

            </form>

        </div>

    <?php

        }
    }

    if (!$found) {

        echo "<div class='student-card'>";
        echo "<p>No students found.</p>";
        echo "</div>";

    }

    ?>


    <a href="dashboard.php" class="back">
        ← Back to Admin Dashboard
    </a>

</div>

</body>

</html>