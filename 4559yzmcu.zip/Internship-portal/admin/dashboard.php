+<?php

session_start();


$adminName = "Administrator";
$adminRole = "Admin";


$totalStudents = 120;
$totalCompanies = 25;
$totalInternships = 45;
$totalApplications = 180;

$activities = [
    "New student registered",
    "New company registered",
    "New internship added",
    "New application received"
];


$message = "Welcome to the Admin Dashboard";

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f2f5f9;
        }

        header {
            background: #5B2C83;
            color: white;
            padding: 25px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 30px;
        }

        header p {
            margin: 8px 0 0;
        }

        nav {
            background: white;
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 6px #ccc;
        }

        nav a {
            text-decoration: none;
            color: #5B2C83;
            font-weight: bold;
            margin: 0 12px;
        }

        nav a:hover {
            color: #000;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
        }

        .welcome {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 3px 10px #ddd;
        }

        .welcome h2 {
            color: #1f4e79;
            margin-top: 0;
        }

        .welcome p {
            color: #555;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
        }

        .card .icon {
            font-size: 35px;
        }

        .card h3 {
            font-size: 30px;
            color: #1f4e79;
            margin: 10px 0;
        }

        .card p {
            font-weight: bold;
            color: #555;
        }

        .activity {
            background: white;
            margin-top: 30px;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 10px #ddd;
        }

        .activity h2 {
            color: #1f4e79;
        }

        .activity li {
            padding: 10px;
            margin-bottom: 8px;
            background: #f5f8fb;
            border-radius: 6px;
        }

        .logout {
            color: #d32f2f;
        }

        @media (max-width: 900px) {

            .cards {
                grid-template-columns: 1fr 1fr;
            }

            nav a {
                display: inline-block;
                margin: 8px;
            }

        }

        @media (max-width: 500px) {

            .cards {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>

<body>

<header>

    <h1>🎓 Internship Portal</h1>

    <p>
        Admin Panel - 
        <?php echo htmlspecialchars($adminName); ?>
    </p>

</header>


<nav>

    <a href="dashboard.php">🏠 Dashboard</a>

    <a href="students.php">👨‍🎓 Students</a>

    <a href="companies.php">🏢 Companies</a>

    <a href="internships.php">💼 Internships</a>

    <a href="application.php">📄 Applications</a>

    <a class="logout" href="../logout.php">🚪 Logout</a>

</nav>


<div class="container">

    <div class="welcome">

        <h2>
            <?php echo $message; ?>
        </h2>

        <p>
            Welcome, 
            <strong>
                <?php echo htmlspecialchars($adminName); ?>
            </strong>
        </p>

        <p>
            Role:
            <strong>
                <?php echo htmlspecialchars($adminRole); ?>
            </strong>
        </p>

        <p>
            Here you can manage students, companies,
            internships and applications.
        </p>

    </div>


    

    <div class="cards">

        <div class="card">

            <div class="icon">👨‍🎓</div>

            <h3>
                <?php echo $totalStudents; ?>
            </h3>

            <p>Total Students</p>

        </div>


        <div class="card">

            <div class="icon">🏢</div>

            <h3>
                <?php echo $totalCompanies; ?>
            </h3>

            <p>Total Companies</p>

        </div>


        <div class="card">

            <div class="icon">💼</div>

            <h3>
                <?php echo $totalInternships; ?>
            </h3>

            <p>Total Internships</p>

        </div>


        <div class="card">

            <div class="icon">📄</div>

            <h3>
                <?php echo $totalApplications; ?>
            </h3>

            <p>Total Applications</p>

        </div>

    </div>


    

    <div class="activity">

        <h2>📢 Recent Activities</h2>

        <ul>

            <?php

            foreach ($activities as $activity) {

                echo "<li>✅ " .
                     htmlspecialchars($activity) .
                     "</li>";

            }

            ?>

        </ul>

    </div>

</div>

</body>

</html>