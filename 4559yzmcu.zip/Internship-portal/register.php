<?php

$name = "";
$email = "";
$password = "";
$role = "";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $role = $_POST["role"];

    if ($name == "" || $email == "" || $password == "" || $role == "") {

        $message = "Please fill all the fields.";

    } elseif (strlen($password) < 6) {

        $message = "Password must contain at least 6 characters.";

    } else {

        header("Location: login.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Create Account</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #eef3f8;
        }

        header {
            background: #1f4e79;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 500px;
            margin: 40px auto;
            padding: 20px;
        }

        .form-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px #ccc;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-bottom: 25px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 7px;
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #bbb;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 15px;
        }

        input:focus,
        select:focus {
            border-color: #1f4e79;
            outline: none;
        }

        button {
            width: 100%;
            padding: 13px;
            background: #1f4e79;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #163b5c;
        }

        .message {
            background: #ffebee;
            color: #c62828;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 6px;
            text-align: center;
        }

        .links {
            text-align: center;
            margin-top: 20px;
        }

        .links a {
            color: #1f4e79;
            text-decoration: none;
            font-weight: bold;
        }

        .links a:hover {
            text-decoration: underline;
        }

    </style>

</head>

<body>

<header>

    <h1>🎓 Internship Portal</h1>

    <p>College Internship Application Portal</p>

</header>

<div class="container">

    <div class="form-box">

        <h2>Create Account</h2>

        <?php if ($message != "") { ?>

            <div class="message">

                <?php
                echo htmlspecialchars($message);
                ?>

            </div>

        <?php } ?>


        <form method="POST" action="">

            <label>Full Name</label>

            <input
                type="text"
                name="name"
                placeholder="Enter your full name"
                value="<?php echo htmlspecialchars($name); ?>"
                required
            >


            <label>Email</label>

            <input
                type="email"
                name="email"
                placeholder="Enter your email"
                value="<?php echo htmlspecialchars($email); ?>"
                required
            >


            <label>Password</label>

            <input
                type="password"
                name="password"
                placeholder="Enter password"
                required
            >


            <label>Register As</label>

            <select name="role" required>

                <option value="">Select Role</option>

                <option value="student"
                    <?php
                    if ($role == "student") echo "selected";
                    ?>>
                    Student
                </option>

                <option value="company"
                    <?php
                    if ($role == "company") echo "selected";
                    ?>>
                    Company
                </option>

                <option value="admin"
                    <?php
                    if ($role == "admin") echo "selected";
                    ?>>
                    Admin
                </option>

            </select>


            <button type="submit">
                Create Account
            </button>

        </form>


        <div class="links">

            <p>
                Already have an account?
                <a href="login.php">Login</a>
            </p>

            <p>
                <a href="index.php">← Back to Home</a>
            </p>

        </div>

    </div>

</div>

</body>

</html>