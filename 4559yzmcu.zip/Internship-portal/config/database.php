<?php

$host = "db01.dbhost.dev";
$username = "user_455bwhfxq";
$password = "p455bwhfxq";
$database = "db_455bwhfxq";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

?>