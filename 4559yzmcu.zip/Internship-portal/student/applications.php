<?php

session_start();
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "student";
}
$applications = [

    1 => [
        "internship" => "PHP Web Development Intern",
        "company" => "Tech Solutions",
        "applied_date" => "02-10-2026",
        "status" => "Under Review"
    ],

    2 => [
        "internship" => "Python Developer Intern",
        "company" => "Innovate Labs",
        "applied_date" => "01-10-2026",
        "status" => "Shortlisted"
    ],

    3 => [
        "internship" => "UI/UX Design Intern",
        "company" => "Digital Works",
        "applied_date" => "28-09-2026",
        "status" => "Rejected"
    ],

    4 => [
        "internship" => "Java Developer Intern",
        "company" => "Code World",
        "applied_date" => "25-09-2026",
        "status" => "Pending"
    ],

    5 => [
        "internship" => "Data Science Intern",
        "company" => "DataTech Solutions",
        "applied_date" => "22-09-2026",
        "status" => "Selected"
    ],

    6 => [
        "internship" => "Frontend Developer Intern",
        "company" => "Web Innovations",
        "applied_date" => "20-09-2026",
        "status" => "Under Review"
    ]
];
$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}
$selectedStatus = "";

if (isset($_GET["status"])) {
    $selectedStatus = trim($_GET["status"]);
}
$totalApplications = count($applications);

$shortlisted = 0;
$selected = 0;
$rejected = 0;

foreach ($applications as $application) {

    if ($application["status"] == "Shortlisted") {
        $shortlisted++;
    }

    if ($application["status"] == "Selected") {
        $selected++;
    }

    if ($application["status"] == "Rejected") {
        $rejected++;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Applications - Internship Portal</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f9;
    color: #333;
}

.header {
    background: #087F5B;
    color: white;
    padding: 20px;
}

.header h1 {
    margin: 0;
    font-size: 26px;
}

.header p {
    margin: 6px 0 0;
}

.navbar {
    background: white;
    padding: 15px 25px;
    box-shadow: 0 2px 8px #ccc;
}

.navbar a {
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
    margin-right: 20px;
}

.navbar a:hover {
    color: #0b7dda;
}

.container {
    width: 95%;
    max-width: 1200px;
    margin: 30px auto;
}

.page-title {
    color: #1f4e79;
    margin-bottom: 20px;
}

.stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    margin-bottom: 25px;
}

.stat-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 3px 10px #ddd;
}

.stat-box h2 {
    margin: 5px 0;
    color: #1f4e79;
}

.stat-box p {
    margin: 0;
    color: #666;
}

.search-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 3px 10px #ddd;
    margin-bottom: 25px;
}

.search-box form {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.search-box input,
.search-box select {
    padding: 12px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

.search-box input {
    flex: 1;
    min-width: 220px;
}

.search-box select {
    min-width: 180px;
}

.search-box button {
    padding: 12px 20px;
    background: #087F5B;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}

.search-box button:hover {
    background: #163b5c;
}

.application-card {
    background: white;
    padding: 22px;
    margin-bottom: 18px;
    border-radius: 10px;
    box-shadow: 0 3px 10px #ddd;
}

.application-card h3 {
    margin-top: 0;
    color: #1f4e79;
}

.application-info {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-top: 15px;
}

.info {
    background: #f8fafc;
    padding: 12px;
    border-radius: 6px;
}

.info strong {
    color: #444;
}

.status {
    display: inline-block;
    padding: 7px 14px;
    border-radius: 20px;
    font-weight: bold;
    font-size: 13px;
}

.pending {
    background: #fff3cd;
    color: #856404;
}

.review {
    background: #cfe2ff;
    color: #084298;
}

.shortlisted {
    background: #d1e7dd;
    color: #0f5132;
}

.selected {
    background: #198754;
    color: white;
}

.rejected {
    background: #f8d7da;
    color: #842029;
}

.no-result {
    background: white;
    padding: 30px;
    text-align: center;
    border-radius: 10px;
    color: #777;
}

.back-btn {
    display: inline-block;
    margin-top: 20px;
    padding: 12px 20px;
    background: #1f4e79;
    color: white;
    text-decoration: none;
    border-radius: 6px;
}

.back-btn:hover {
    background: #163b5c;
}

@media (max-width: 700px) {

    .stats {
        grid-template-columns: 1fr 1fr;
    }

    .application-info {
        grid-template-columns: 1fr;
    }

}

</style>

</head>

<body>

<div class="header">

    <h1>🎓 Internship Portal</h1>

    <p>Student Application Management</p>

</div>

<div class="navbar">

    <a href="dashboard.php">Dashboard</a>

    <a href="profile.php">My Profile</a>

    <a href="internships.php">Find Internships</a>

    <a href="applications.php">My Applications</a>

    <a href="../logout.php">Logout</a>

</div>


<div class="container">

    <h2 class="page-title">📋 My Internship Applications</h2>

    <div class="stats">

        <div class="stat-box">
            <p>Total Applications</p>
            <h2><?php echo $totalApplications; ?></h2>
        </div>

        <div class="stat-box">
            <p>Shortlisted</p>
            <h2><?php echo $shortlisted; ?></h2>
        </div>

        <div class="stat-box">
            <p>Selected</p>
            <h2><?php echo $selected; ?></h2>
        </div>

        <div class="stat-box">
            <p>Rejected</p>
            <h2><?php echo $rejected; ?></h2>
        </div>

    </div>

    <div class="search-box">

        <form method="GET" action="">

            <input
                type="text"
                name="search"
                placeholder="Search internship or company..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <select name="status">

                <option value="">All Status</option>

                <option value="Pending"
                    <?php if ($selectedStatus == "Pending") echo "selected"; ?>>
                    Pending
                </option>

                <option value="Under Review"
                    <?php if ($selectedStatus == "Under Review") echo "selected"; ?>>
                    Under Review
                </option>

                <option value="Shortlisted"
                    <?php if ($selectedStatus == "Shortlisted") echo "selected"; ?>>
                    Shortlisted
                </option>

                <option value="Selected"
                    <?php if ($selectedStatus == "Selected") echo "selected"; ?>>
                    Selected
                </option>

                <option value="Rejected"
                    <?php if ($selectedStatus == "Rejected") echo "selected"; ?>>
                    Rejected
                </option>

            </select>

            <button type="submit">🔍 Search</button>

        </form>

    </div>

    <?php

    $found = false;

    foreach ($applications as $id => $application) {

        $searchText =
            $application["internship"] . " " .
            $application["company"];

        $searchMatch = true;
        $statusMatch = true;

        if ($search != "") {

            if (stripos($searchText, $search) === false) {
                $searchMatch = false;
            }

        }

        if ($selectedStatus != "") {

            if ($application["status"] != $selectedStatus) {
                $statusMatch = false;
            }

        }

        if ($searchMatch && $statusMatch) {

            $found = true;

            $statusClass = "pending";

            if ($application["status"] == "Under Review") {
                $statusClass = "review";
            }

            if ($application["status"] == "Shortlisted") {
                $statusClass = "shortlisted";
            }

            if ($application["status"] == "Selected") {
                $statusClass = "selected";
            }

            if ($application["status"] == "Rejected") {
                $statusClass = "rejected";
            }

    ?>

        <div class="application-card">

            <h3>
                <?php echo htmlspecialchars($application["internship"]); ?>
            </h3>

            <div class="application-info">

                <div class="info">
                    <strong>🏢 Company:</strong><br>
                    <?php echo htmlspecialchars($application["company"]); ?>
                </div>

                <div class="info">
                    <strong>📅 Applied Date:</strong><br>
                    <?php echo htmlspecialchars($application["applied_date"]); ?>
                </div>

                <div class="info">
                    <strong>📌 Application ID:</strong><br>
                    APP-<?php echo $id; ?>
                </div>

                <div class="info">
                    <strong>📊 Status:</strong><br><br>

                    <span class="status <?php echo $statusClass; ?>">
                        <?php echo htmlspecialchars($application["status"]); ?>
                    </span>

                </div>

            </div>

        </div>

    <?php

        }

    }


    if (!$found) {

    ?>

        <div class="no-result">

            <h3>❌ No Applications Found</h3>

            <p>
                No application matches your search or selected status.
            </p>

        </div>

    <?php

    }

    ?>


    <a href="dashboard.php" class="back-btn">
        ← Back to Dashboard
    </a>

</div>

</body>

</html>