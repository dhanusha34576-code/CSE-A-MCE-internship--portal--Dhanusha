<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Available Internships</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f3f6ff;
            color: #172033;
        }

        header {
            background: white;
            padding: 20px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px #0001;
        }

        header h2 {
            color: #3156d3;
        }

        header a {
            color: #3156d3;
            text-decoration: none;
            font-weight: bold;
        }

        .title {
            padding: 50px 8%;
            background: #eef2ff;
        }

        .title h1 {
            font-size: 38px;
            margin-bottom: 10px;
        }

        .title p {
            color: #687386;
            font-size: 17px;
        }

        .internships {
            padding: 45px 8%;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
        }

        .card {
            background: white;
            padding: 28px;
            border-radius: 16px;
            box-shadow: 0 5px 20px #0000000d;
        }

        .company {
            color: #3156d3;
            font-weight: bold;
            font-size: 14px;
        }

        .card h2 {
            margin: 12px 0;
            font-size: 21px;
        }

        .card p {
            color: #687386;
            line-height: 1.6;
            margin-bottom: 18px;
        }

        .details {
            margin-bottom: 20px;
            color: #444;
            line-height: 1.8;
        }

        .btn {
            display: inline-block;
            background: #3156d3;
            color: white;
            text-decoration: none;
            padding: 11px 18px;
            border-radius: 7px;
            font-weight: bold;
        }

        .btn:hover {
            background: #2444b5;
        }

        @media (max-width: 800px) {

            .internships {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>


<body>


<header>

    <h2>🎓 Student Portal</h2>

    <a href="dashboard.php">
        ← Dashboard
    </a>

</header>


<section class="title">

    <h1>Available Internships</h1>

    <p>
        Explore internship opportunities and start your career journey.
    </p>

</section>


<section class="internships">


    <!-- Internship 1 -->

    <div class="card">

        <div class="company">
            TECH SOLUTIONS
        </div>

        <h2>
            PHP Web Development Intern
        </h2>

        <p>
            Learn PHP, MySQL and web development
            through practical projects.
        </p>

        <div class="details">

            📍 Chennai / Remote <br>

            ⏱ Duration: 3 Months <br>

            💻 Skills: PHP, MySQL, HTML, CSS

        </div>

        <a href="internship_details.php" class="btn">
            View Details
        </a>

    </div>


    <!-- Internship 2 -->

    <div class="card">

        <div class="company">
            INNOVATE LABS
        </div>

        <h2>
            Python Developer Intern
        </h2>

        <p>
            Work on Python programming and
            real-world software projects.
        </p>

        <div class="details">

            📍 Bangalore / Remote <br>

            ⏱ Duration: 3 Months <br>

            💻 Skills: Python, SQL, Git

        </div>

        <a href="internship_details.php" class="btn">
            View Details
        </a>

    </div>


    <!-- Internship 3 -->

    <div class="card">

        <div class="company">
            DIGITAL WORKS
        </div>

        <h2>
            UI/UX Design Intern
        </h2>

        <p>
            Design modern websites and improve
            your UI/UX design skills.
        </p>

        <div class="details">

            📍 Chennai <br>

            ⏱ Duration: 2 Months <br>

            🎨 Skills: Figma, UI Design, UX

        </div>

        <a href="internship_details.php" class="btn">
            View Details
        </a>

    </div>


</section>


</body>

</html>