<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f3f6ff;
            color: #172033;
        }

        header {
            background: white;
            padding: 20px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px #0001;
        }

        header h2 {
            color: #3156d3;
        }

        a {
            text-decoration: none;
        }

        .logout {
            background: #3156d3;
            color: white;
            padding: 10px 18px;
            border-radius: 7px;
        }

        main {
            padding: 45px 7%;
        }

        .welcome {
            margin-bottom: 30px;
        }

        .welcome p {
            color: #687386;
            margin-top: 10px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
        }

        .card {
            background: white;
            padding: 28px;
            border-radius: 15px;
            box-shadow: 0 5px 20px #00000008;
        }

        .icon {
            font-size: 35px;
        }

        .card h3 {
            margin: 18px 0 12px;
        }

        .card p {
            color: #687386;
            line-height: 1.6;
            margin-bottom: 22px;
        }

        .btn {
            display: inline-block;
            background: #3156d3;
            color: white;
            padding: 11px 16px;
            border-radius: 7px;
        }

        @media (max-width: 700px) {
            .cards {
                grid-template-columns: 1fr;
            }

            header {
                padding: 18px 5%;
            }
        }
    </style>
</head>

<body>

<header>
    <h2>🎓 Student Portal</h2>
    <a href="../index.php" class="logout">Home</a>
</header>

<main>
    <div class="welcome">
        <h1>Student Dashboard</h1>
        <p>Welcome to your College Internship Application Portal!</p>
    </div>

    <div class="cards">

        <div class="card">
            <div class="icon">👤</div>
            <h3>My Profile</h3>
            <p>View and update your personal details and skills.</p>
            <a href="profile.php" class="btn">My Profile</a>
        </div>

        <div class="card">
            <div class="icon">💼</div>
            <h3>Find Internships</h3>
            <p>Explore internship opportunities and their details.</p>
            <a href="internships.php" class="btn">Explore</a>
        </div>

        <div class="card">
            <div class="icon">📋</div>
            <h3>My Applications</h3>
            <p>View your internship applications and their status.</p>
            <a href="applications.php" class="btn">Track Status</a>
        </div>

    </div>
</main>

</body>
</html>