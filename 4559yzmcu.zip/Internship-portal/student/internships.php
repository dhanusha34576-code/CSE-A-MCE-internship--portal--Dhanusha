<?php

session_start();
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "student";
}
$internships = [

    1 => [
        "company" => "Tech Solutions",
        "title" => "PHP Web Development Intern",
        "location" => "Chennai / Remote",
        "duration" => "3 Months",
        "skills" => "PHP, MySQL, HTML, CSS",
        "description" => "Work on web application development using PHP and MySQL.",
        "eligibility" => "B.E / B.Tech students with basic programming knowledge."
    ],

    2 => [
        "company" => "Innovate Labs",
        "title" => "Python Developer Intern",
        "location" => "Bangalore / Remote",
        "duration" => "3 Months",
        "skills" => "Python, SQL, Git",
        "description" => "Develop Python applications and work with databases.",
        "eligibility" => "Students with basic Python programming knowledge."
    ],

    3 => [
        "company" => "Digital Works",
        "title" => "UI/UX Design Intern",
        "location" => "Chennai",
        "duration" => "2 Months",
        "skills" => "Figma, UI Design, UX",
        "description" => "Create user-friendly website and application designs.",
        "eligibility" => "Students interested in UI/UX design."
    ],

    4 => [
        "company" => "TCS",
        "title" => "Software Developer Intern",
        "location" => "Chennai / Remote",
        "duration" => "3 Months",
        "skills" => "Java, SQL, Git",
        "description" => "Work on software development and database projects.",
        "eligibility" => "B.E / B.Tech students with basic Java knowledge."
    ],

    5 => [
        "company" => "Infosys",
        "title" => "Web Development Intern",
        "location" => "Coimbatore / Remote",
        "duration" => "3 Months",
        "skills" => "HTML, CSS, JavaScript, PHP",
        "description" => "Develop and maintain modern web applications.",
        "eligibility" => "Students with basic web development knowledge."
    ],

    6 => [
        "company" => "Wipro",
        "title" => "Data Science Intern",
        "location" => "Bangalore / Remote",
        "duration" => "4 Months",
        "skills" => "Python, Pandas, Machine Learning",
        "description" => "Analyze data and build basic machine learning models.",
        "eligibility" => "Students interested in Python and Data Science."
    ],

    7 => [
        "company" => "Accenture",
        "title" => "Cloud Computing Intern",
        "location" => "Chennai / Remote",
        "duration" => "3 Months",
        "skills" => "Cloud, AWS, Linux",
        "description" => "Learn cloud technologies and work on cloud-based projects.",
        "eligibility" => "B.E / B.Tech students with basic cloud knowledge."
    ],

    8 => [
        "company" => "Zoho",
        "title" => "Java Developer Intern",
        "location" => "Chennai",
        "duration" => "3 Months",
        "skills" => "Java, OOP, SQL",
        "description" => "Develop Java applications and work with databases.",
        "eligibility" => "Students with basic Java programming skills."
    ],

    9 => [
        "company" => "Freshworks",
        "title" => "UI/UX Design Intern",
        "location" => "Chennai / Remote",
        "duration" => "2 Months",
        "skills" => "Figma, UI Design, UX",
        "description" => "Create user-friendly interfaces and improve user experience.",
        "eligibility" => "Students interested in UI/UX and design."
    ],

    10 => [
        "company" => "HCL Technologies",
        "title" => "Cyber Security Intern",
        "location" => "Noida / Remote",
        "duration" => "3 Months",
        "skills" => "Cyber Security, Networking, Linux",
        "description" => "Learn basic security practices and network protection.",
        "eligibility" => "Students interested in Cyber Security and Networking."
    ]
];
$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}
$filteredInternships = [];

foreach ($internships as $id => $internship) {

    if ($search == "") {

        $filteredInternships[$id] = $internship;

    } else {

        $searchText = strtolower($search);

        $company = strtolower($internship["company"]);
        $title = strtolower($internship["title"]);
        $location = strtolower($internship["location"]);
        $skills = strtolower($internship["skills"]);

        if (
            strpos($company, $searchText) !== false ||
            strpos($title, $searchText) !== false ||
            strpos($location, $searchText) !== false ||
            strpos($skills, $searchText) !== false
        ) {
            $filteredInternships[$id] = $internship;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Find Internships</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f9;
}

header {
    background: #087F5B;
    color: white;
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header h1 {
    margin: 0;
    font-size: 25px;
}

header a {
    color: white;
    text-decoration: none;
    margin-left: 20px;
    font-weight: bold;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 30px auto;
}

.title-section {
    text-align: center;
    margin-bottom: 25px;
}

.title-section h2 {
    color: #1f4e79;
    margin-bottom: 8px;
}

.title-section p {
    color: #666;
}

.search-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 3px 10px #087F5B;
    margin-bottom: 30px;
}

.search-box form {
    display: flex;
    gap: 10px;
}

.search-box input {
    flex: 1;
    padding: 13px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

.search-box button {
    padding: 13px 25px;
    background: #08755B;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}

.internship-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px #ddd;
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

.card h3 {
    color: #1f4e79;
    margin-top: 0;
}

.company {
    font-weight: bold;
    color: #444;
    margin-bottom: 12px;
}

.info {
    margin: 8px 0;
    color: #555;
}

.skills {
    background: #eef5ff;
    padding: 10px;
    border-radius: 6px;
    margin: 15px 0;
    color: #1f4e79;
}

.buttons {
    display: flex;
    gap: 10px;
    margin-top: 20px;
}

.buttons a {
    flex: 1;
    text-align: center;
    padding: 11px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
}

.details {
    background: #e8eef5;
    color: #1f4e79;
}

.apply {
    background: #1f4e79;
    color: white;
}
.no-result {
    background: white;
    padding: 30px;
    text-align: center;
    border-radius: 10px;
    color: #777;
}
footer {
    margin-top: 40px;
    background: #1f4e79;
    color: white;
    text-align: center;
    padding: 15px;
}

</style>

</head>

<body>


<header>

    <h1>🎓 Internship Portal</h1>

    <div>
        <a href="dashboard.php">Dashboard</a>
        <a href="applications.php">My Applications</a>
        <a href="../logout.php">Logout</a>
    </div>

</header>


<div class="container">

    <div class="title-section">

        <h2>Find Internships</h2>

        <p>Search and apply for the best internship opportunities</p>

</div>
    <div class="search-box">

        <form method="GET" action="">

            <input
                type="text"
                name="search"
                placeholder="Search by company, title, location or skill..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <button type="submit">🔍 Search</button>

        </form>

    </div>

    <?php if (count($filteredInternships) > 0) { ?>

        <div class="internship-grid">

            <?php foreach ($filteredInternships as $id => $internship) { ?>

                <div class="card">

                    <h3>
                        <?php echo htmlspecialchars($internship["title"]); ?>
                    </h3>

                    <div class="company">
                        🏢 <?php echo htmlspecialchars($internship["company"]); ?>
                    </div>

                    <div class="info">
                        📍 <strong>Location:</strong>
                        <?php echo htmlspecialchars($internship["location"]); ?>
                    </div>

                    <div class="info">
                        ⏳ <strong>Duration:</strong>
                        <?php echo htmlspecialchars($internship["duration"]); ?>
                    </div>

                    <div class="skills">
                        💻 <strong>Skills:</strong><br>
                        <?php echo htmlspecialchars($internship["skills"]); ?>
                    </div>

                    <p>
                        <?php echo htmlspecialchars($internship["description"]); ?>
                    </p>

                    <div class="buttons">

                        <a
                            class="details"
                            href="internship_details.php?id=<?php echo $id; ?>"
                        >
                            View Details
                        </a>

                        <a
                            class="apply"
                            href="apply.php?id=<?php echo $id; ?>"
                        >
                            Apply Now
                        </a>

                    </div>

                </div>

            <?php } ?>

        </div>

    <?php } else { ?>

        <div class="no-result">

            <h3>❌ No internships found</h3>

            <p>Try searching with another keyword.</p>

        </div>

    <?php } ?>

</div>


<footer>

    <p>© 2026 College Internship Application Portal</p>

</footer>


</body>

</html>