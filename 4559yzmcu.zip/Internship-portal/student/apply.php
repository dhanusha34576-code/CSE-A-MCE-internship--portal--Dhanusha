<?php

session_start();
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "student";
}
$internships = [

    1 => [
        "company" => "Tech Solutions",
        "title" => "PHP Web Development Intern",
        "location" => "Chennai / Remote",
        "duration" => "3 Months",
        "skills" => "PHP, MySQL, HTML, CSS"
    ],

    2 => [
        "company" => "Innovate Labs",
        "title" => "Python Developer Intern",
        "location" => "Bangalore / Remote",
        "duration" => "3 Months",
        "skills" => "Python, SQL, Git"
    ],

    3 => [
        "company" => "Digital Works",
        "title" => "UI/UX Design Intern",
        "location" => "Chennai",
        "duration" => "2 Months",
        "skills" => "Figma, UI/UX, Photoshop"
    ],

    4 => [
        "company" => "Code World",
        "title" => "Java Developer Intern",
        "location" => "Coimbatore",
        "duration" => "3 Months",
        "skills" => "Java, SQL, OOP"
    ],

    5 => [
        "company" => "DataTech Solutions",
        "title" => "Data Science Intern",
        "location" => "Chennai / Remote",
        "duration" => "4 Months",
        "skills" => "Python, Pandas, Machine Learning"
    ],

    6 => [
        "company" => "Web Innovations",
        "title" => "Frontend Developer Intern",
        "location" => "Bangalore",
        "duration" => "2 Months",
        "skills" => "HTML, CSS, JavaScript"
    ]
];

$id = 1;

if (isset($_GET["id"])) {
    $id = (int) $_GET["id"];
}

if (!isset($internships[$id])) {
    $id = 1;
}

$internship = $internships[$id];

$name = "";
$email = "";
$phone = "";
$college = "";
$course = "";
$skills = "";
$message = "";

$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $college = trim($_POST["college"] ?? "");
    $course = trim($_POST["course"] ?? "");
    $skills = trim($_POST["skills"] ?? "");

    if (
        $name == "" ||
        $email == "" ||
        $phone == "" ||
        $college == "" ||
        $course == "" ||
        $skills == ""
    ) {

        $message = "Please fill all the fields.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Please enter a valid email address.";

    } elseif (strlen($phone) < 10) {

        $message = "Please enter a valid phone number.";

    } else {

        $success = true;

        $message = "Your internship application has been submitted successfully.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Apply Internship - Internship Portal</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #eef3f8;
    color: #333;
}

header {
    background: #087F5B;
    color: white;
    padding: 20px;
    text-align: center;
}

header h1 {
    margin: 0;
    font-size: 28px;
}

header p {
    margin: 7px 0 0;
}

/* Navigation */

.navbar {
    background: white;
    padding: 15px 25px;
    box-shadow: 0 2px 8px #ccc;
}

.navbar a {
    text-decoration: none;
    color: #1f4e79;
    font-weight: bold;
    margin-right: 20px;
}

.navbar a:hover {
    color: #0b7dda;
}

.container {
    width: 95%;
    max-width: 1000px;
    margin: 30px auto;
}

.internship-box {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 3px 12px #ddd;
    margin-bottom: 25px;
}

.internship-box h2 {
    color: #1f4e79;
    margin-top: 0;
}

.details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.detail {
    background: #f5f8fb;
    padding: 14px;
    border-radius: 7px;
}

.detail strong {
    color: #1f4e79;
}

.form-box {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 3px 12px #ddd;
}

.form-box h2 {
    color: #1f4e79;
    margin-top: 0;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 7px;
    margin-top: 15px;
}

input,
textarea {
    width: 100%;
    padding: 13px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

textarea {
    height: 100px;
    resize: vertical;
}

input:focus,
textarea:focus {
    outline: none;
    border-color: #1f4e79;
}

button {
    width: 100%;
    padding: 14px;
    margin-top: 22px;
    background: #1f4e79;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background: #163b5c;
}

.error {
    background: #f8d7da;
    color: #842029;
    padding: 13px;
    border-radius: 6px;
    margin-bottom: 20px;
}

.success {
    background: #d1e7dd;
    color: #0f5132;
    padding: 18px;
    border-radius: 6px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: bold;
}

.links {
    text-align: center;
    margin-top: 20px;
}

.links a {
    display: inline-block;
    margin: 5px;
    padding: 10px 18px;
    background: #1f4e79;
    color: white;
    text-decoration: none;
    border-radius: 6px;
}

.links a:hover {
    background: #163b5c;
}

@media (max-width: 700px) {

    .details {
        grid-template-columns: 1fr;
    }

    .navbar a {
        display: block;
        margin-bottom: 10px;
    }

}

</style>

</head>

<body>


<header>

    <h1>🎓 Internship Portal</h1>

    <p>College Internship Application Portal</p>

</header>


<div class="navbar">

    <a href="dashboard.php">Dashboard</a>

    <a href="profile.php">My Profile</a>

    <a href="internships.php">Find Internships</a>

    <a href="applications.php">My Applications</a>

    <a href="../logout.php">Logout</a>

</div>


<div class="container">

    <div class="internship-box">

        <h2>
            Apply for Internship
        </h2>

        <div class="details">

            <div class="detail">

                <strong>Company:</strong><br>

                <?php
                echo htmlspecialchars($internship["company"]);
                ?>

            </div>


            <div class="detail">

                <strong>Internship:</strong><br>

                <?php
                echo htmlspecialchars($internship["title"]);
                ?>

            </div>


            <div class="detail">

                <strong>Location:</strong><br>

                <?php
                echo htmlspecialchars($internship["location"]);
                ?>

            </div>


            <div class="detail">

                <strong>Duration:</strong><br>

                <?php
                echo htmlspecialchars($internship["duration"]);
                ?>

            </div>


            <div class="detail">

                <strong>Required Skills:</strong><br>

                <?php
                echo htmlspecialchars($internship["skills"]);
                ?>

            </div>

        </div>

    </div>

    <div class="form-box">

        <h2>📝 Application Form</h2>


        <?php if ($success) { ?>

            <div class="success">

                <?php
                echo htmlspecialchars($message);
                ?>

                <br><br>

                You can now track your application from
                <b>My Applications</b>.

            </div>


            <div class="links">

                <a href="applications.php">
                    📋 My Applications
                </a>

                <a href="internships.php">
                    🔍 Find More Internships
                </a>

            </div>

        <?php } else { ?>


            <?php if ($message != "") { ?>

                <div class="error">

                    <?php
                    echo htmlspecialchars($message);
                    ?>

                </div>

            <?php } ?>


            <form method="POST" action="">


                <label>Full Name</label>

                <input
                    type="text"
                    name="name"
                    placeholder="Enter your full name"
                    value="<?php echo htmlspecialchars($name); ?>"
                    required
                >


                <label>Email</label>

                <input
                    type="email"
                    name="email"
                    placeholder="Enter your email"
                    value="<?php echo htmlspecialchars($email); ?>"
                    required
                >


                <label>Phone Number</label>

                <input
                    type="text"
                    name="phone"
                    placeholder="Enter your phone number"
                    value="<?php echo htmlspecialchars($phone); ?>"
                    required
                >


                <label>College Name</label>

                <input
                    type="text"
                    name="college"
                    placeholder="Enter your college name"
                    value="<?php echo htmlspecialchars($college); ?>"
                    required
                >


                <label>Course</label>

                <input
                    type="text"
                    name="course"
                    placeholder="Example: B.Tech CSE"
                    value="<?php echo htmlspecialchars($course); ?>"
                    required
                >


                <label>Skills</label>

                <textarea
                    name="skills"
                    placeholder="Enter your skills"
                    required
                ><?php echo htmlspecialchars($skills); ?></textarea>


                <button type="submit">
                    🚀 Submit Application
                </button>


            </form>


            <div class="links">

                <a href="internships.php">
                    ← Back to Internships
                </a>

            </div>


        <?php } ?>

    </div>

</div>

</body>

</html>