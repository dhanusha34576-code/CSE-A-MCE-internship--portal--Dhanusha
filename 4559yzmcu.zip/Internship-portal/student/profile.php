<?php

session_start();
if (!isset($_SESSION["user_role"])) {
    $_SESSION["user_role"] = "student";
}
$name = "";
$email = "";
$phone = "";
$college = "";
$course = "";
$skills = "";
$message = "";
$success = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $college = trim($_POST["college"]);
    $course = trim($_POST["course"]);
    $skills = trim($_POST["skills"]);

    if (
        $name == "" ||
        $email == "" ||
        $phone == "" ||
        $college == "" ||
        $course == "" ||
        $skills == ""
    ) {

        $message = "Please fill all the fields.";

    } else {

        $success = true;
        $message = "Profile saved successfully.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Student Profile</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #eef3f8;
        }

        header {
            background: #087F5B;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 100%;
            max-width: 750px;
            margin: 35px auto;
            padding: 20px;
        }

        .profile-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px #ccc;
        }

        h2 {
            text-align: center;
            color: #1f4e79;
            margin-bottom: 25px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        input,
        textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border: 1px solid #bbb;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        input:focus,
        textarea:focus {
            outline: none;
            border-color: #1f4e79;
        }

        button {
            width: 100%;
            padding: 13px;
            background: #087F5B;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #163b5c;
        }

        .message {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 6px;
            text-align: center;
        }

        .success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .error {
            background: #ffebee;
            color: #c62828;
        }

        .links {
            text-align: center;
            margin-top: 20px;
        }

        .links a {
            color: #1f4e79;
            text-decoration: none;
            font-weight: bold;
        }

        .links a:hover {
            text-decoration: underline;
        }

    </style>

</head>

<body>

<header>

    <h1>🎓 Student Portal</h1>

    <p>Student Profile</p>

</header>

<div class="container">

    <div class="profile-box">

        <h2>My Profile</h2>

        <?php if ($message != "") { ?>

            <div class="message
            <?php
            echo $success ? "success" : "error";
            ?>">

                <?php
                echo htmlspecialchars($message);
                ?>

            </div>

        <?php } ?>


        <form method="POST" action="">

            <label>Full Name</label>

            <input
                type="text"
                name="name"
                placeholder="Enter your full name"
                value="<?php echo htmlspecialchars($name); ?>"
                required
            >


            <label>Email</label>

            <input
                type="email"
                name="email"
                placeholder="Enter your email"
                value="<?php echo htmlspecialchars($email); ?>"
                required
            >


            <label>Phone Number</label>

            <input
                type="tel"
                name="phone"
                placeholder="Enter your phone number"
                value="<?php echo htmlspecialchars($phone); ?>"
                required
            >


            <label>College Name</label>

            <input
                type="text"
                name="college"
                placeholder="Enter your college name"
                value="<?php echo htmlspecialchars($college); ?>"
                required
            >


            <label>Course</label>

            <input
                type="text"
                name="course"
                placeholder="Example: B.E Computer Science"
                value="<?php echo htmlspecialchars($course); ?>"
                required
            >


            <label>Skills</label>

            <textarea
                name="skills"
                placeholder="Example: PHP, MySQL, HTML, CSS, Java"
                required
            ><?php echo htmlspecialchars($skills); ?></textarea>


            <button type="submit">
                💾 Save Profile
            </button>

        </form>


        <div class="links">

            <p>
                <a href="dashboard.php">
                    ← Back to Dashboard
                </a>
            </p>

        </div>

    </div>

</div>

</body>

</html>